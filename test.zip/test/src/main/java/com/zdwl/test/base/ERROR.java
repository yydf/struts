package com.zdwl.test.base;

public enum ERROR
{
	系统错误(999001),
	该帐号尚未注册(999002),
	用户名或密码错误(999003),
	该管理员帐号已被禁用(999004),
	当前密码不正确(999005),
	已经移到顶部了(999006),
	已经移到底部了(999007),
	验证码发送失败(999008), 
	验证码或手机号不正确(999009);

	final private int val;

	ERROR(int val)
	{
		this.val = val;
	}

	static ERROR valueOf(int i)
	{
		for (ERROR t : ERROR.values())
		{
			if (t.val == i)
				return t;
		}
		return null;
	}
	
	static String nameOf(int i)
	{
		for (ERROR t : ERROR.values())
		{
			if (t.val == i)
				return t.name();
		}
		return null;
	}
}