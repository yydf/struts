package com.zdwl.test.base;

import cn.coder.jdbc.support.DaoSupport;

/**
 * @author zml
 * @version 创建时间：2017-11-21 16:56:00
 */
public class GlobalDao extends DaoSupport {
	
	public boolean exist(Object obj) {
		return jdbc().exist(obj);
	}
	
	public boolean insert(Object obj) {
		return jdbc().insert(obj);
	}
	
	public boolean update(Object obj) {
		return jdbc().insert(obj);
	}
	
	public boolean delete(Object obj) {
		return jdbc().delete(obj);
	}
}