package com.zdwl.test.filter;

import org.apache.log4j.Logger;

import cn.coder.struts.annotation.Order;
import cn.coder.struts.core.Invocation;
import cn.coder.struts.support.Interceptor;

/**
 * com.zdwl.test操作类
 * 
 * @author yydf
 * @since JDK1.8
 * @version 1.0
 */
@Order(2)
public class LoginFilter extends Interceptor {

	private static final Logger logger = Logger.getLogger(LoginFilter.class);

	@Override
	public void intercept(Invocation inv) {
		System.out.println(inv.getRequest());
		System.out.println(inv.getResponse());
		logger.debug(2);
		inv.next();
	}
}
