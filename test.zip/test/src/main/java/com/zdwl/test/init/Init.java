package com.zdwl.test.init;

import com.zdwl.test.utils.ThreadEx;

import cn.coder.jdbc.SqlSessionFactory;
import cn.coder.struts.support.StrutsLoader;

/**
 * 项目初始化
 * 
 * @author yydf
 * @since JDK1.8
 * @version 1.0
 */
public class Init implements StrutsLoader {

	@Override
	public void load() {
		ThreadEx.init();
		// OSSClient.register("", "", "");
		// AcsClient.register("", "");
		// WXApi.forMP("", "");
		// 创建数据源
		SqlSessionFactory.createSessions();
	}

	@Override
	public void destroy() {
		// 销毁数据源
		SqlSessionFactory.destory();
		ThreadEx.clear();
	}

}
