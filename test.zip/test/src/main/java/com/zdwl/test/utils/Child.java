package com.zdwl.test.utils;

import java.util.List;

/**
 * 配合GlobalService.children使用
 * @author YYDF
 *
 * @param <T>
 */
public interface Child<T> {

	int getParentId(T vo);

	int getId(T vo);

	void setChildren(T vo, List<T> list);

}
